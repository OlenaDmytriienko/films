<script setup>
import './index.scss'


</script>



<template>
 
    <div class="container">
       <h1 class="about__title">This is products page page</h1>
    <p class="about__text">Lorem, ipsum dolor.</p>

<div class="box">
  <div class="box__container">
    <div class="box__cart sell">
      <h2>title</h2>
      <div class="img"></div>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus, eaque.</p>
      <button>buy</button>
    </div>
    <div class="box__cart">
      <h2>title</h2>
      <div class="img"></div>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus, eaque.</p>
      <button>buy</button>
    </div>
    <div class="box__cart sell">
      <h2>title</h2>
      <div class="img"></div>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus, eaque.</p>
      <button>buy</button>
    </div>
    <div class="box__cart">
      <h2>title</h2>
      <div class="img"></div>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus, eaque.</p>
      <button>buy</button>
    </div>
    <div class="box__cart">
      <h2>title</h2>
      <div class="img"></div>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus, eaque.</p>
      <button>buy</button>
    </div>
  </div>
</div>

    </div>
   

</template>