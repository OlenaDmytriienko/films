<script setup>
import './index.scss';
import Button from '../../components/Button/Button.vue'

</script>

<template>
  <div class="about">
    <div class="container">
       <h1 class="about__title">This is an about page</h1>
    <p class="about__text">Lorem, ipsum dolor.</p>
<Button text="Saha"/>

    </div>
   
  </div>
</template>



