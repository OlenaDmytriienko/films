<script setup>
import TheWelcome from '@/components/TheWelcome.vue'
</script>

<template>
  <main>
  <div class="about">
    <div class="container">
       <h1 class="about__title">This is products page page</h1>
    <p class="about__text">Lorem, ipsum dolor.</p>


    </div>
   
  </div>
  

    <TheWelcome />
  </main>
</template>
