<script setup>
import { RouterLink, RouterView } from 'vue-router'
import HelloWorld from './components/HelloWorld.vue'
import '../node_modules/reset-css'
import './style/index.scss'
</script>

<template>
    <header class="container">
      <div class="header header-content">
        <a href="./index.html" class="header__logo">Top Films</a>
        <select name="" id="genre" class="header__genre action">
          <option value="1">Tриллер</option>
          <option value="2">Драма</option>
          <option value="3">Криминал</option>
          <option value="4">Мелодрама</option>
          <option value="5">Детектив</option>
          <option value="6">Фантастика</option>
          <option value="7">Приключения</option>
        </select>
        <form>
          <input type="text" class="header__search" placeholder="Search" />
        </form>
      </div>
    </header>
      <div class="container">
      <div class="movie__today"></div>
      <div class="movies">
        <!-- <div class="movie">
          <div class="movie__cover-inner">
            <img src="./img/thor.jpeg" alt="" class="movie__cover" />
            <div class="movie__cover--darkened"></div>
          </div>
          <div class="movie__info">
            <div class="movie__title">Thor: Love and Thunder</div>
            <div class="movie__category">Fantasy</div>
            <div class="movie__average movie__average--green">6.4</div>
          </div>
        </div> -->
      </div>
    </div>
    <div class="container">
      <div class="movie__today"></div>
      <div class="movies">
        <!-- <div class="movie">
          <div class="movie__cover-inner">
            <img src="./img/thor.jpeg" alt="" class="movie__cover" />
            <div class="movie__cover--darkened"></div>
          </div>
          <div class="movie__info">
            <div class="movie__title">Thor: Love and Thunder</div>
            <div class="movie__category">Fantasy</div>
            <div class="movie__average movie__average--green">6.4</div>
          </div>
        </div> -->
      </div>
    </div>

    <div id="myModal" class="modal">
      <span
        class="close"
        onclick="document.getElementById('myModal').style.display='none'"
        >&times;</span>
        <div class="modal__container">
      <img class="modal-content" id="img01" />
      <div class="modal__box">
      <h4 class="modal__title"></h4>
      <h5 class="modal__genre"></h5>
      <p class="modal__year"></p>
      <div class="modal__text"></div>
      <p class="modal__pg"></p></div>
    </div>
    </div>

    <button class="next__page">Show more</button>


   <RouterView />


</template>

